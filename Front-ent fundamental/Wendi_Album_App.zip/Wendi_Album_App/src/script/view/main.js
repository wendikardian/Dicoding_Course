import DataSource from "../data/data-source.js";
import '../components/album-list.js';
import $ from 'jquery';
window.jQuery = window.$ = $;

const main = () => {
        const albumListElement = document.querySelector("album-list");

        $(".button-search").click(() => {
            DataSource.searchAlbum($('#album-search').val()).then(renderResult)
            .catch(fallbackResult);
        });

        const renderResult = (result) => {
            albumListElement.albums = result;
        }

        const fallbackResult = (message) => {
            albumListElement.renderError(message);
        }

        window.onload  = () => {
            DataSource.searchAlbum('').then(renderResult).catch(fallbackResult);
        }


        $('#add-input-album').click(() => {
            const albumInput = $('#album_title_input').val();
            const artistInput = $('#album_artist_input').val();
            const imgUrlInput = $('#img_url_input').val();
            const releaseYearInput = $('#release_year_input').val();
            const topSongInput1 = $('#top_song1_input').val();
            const topSongInput2 = $('#top_song2_input').val();

            const dataAlbum = {
                "artist" : artistInput,
                "img" : imgUrlInput,
                "releaseYear" : releaseYearInput,
                "title" : albumInput,
                "topSong" : [topSongInput1, topSongInput2]
            };
            DataSource.checkAlbum(dataAlbum);
            
        })

        

}

export default main;