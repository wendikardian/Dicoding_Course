const axios = require('axios').default;

class DataSource {
    static searchAlbum(keyword){
        return axios.get('https://wendiapp-favalbum-default-rtdb.firebaseio.com/albums.json')
            .then(response => {
                console.log(response)
                return response.data;
            }).then(responeData => {
                const albums = [];
                for(const key in responeData){
                    const album = {
                        id : key,
                        ...responeData[key]
                    }
                    albums.push(album);
                }
                const filter = albums.filter(data => data['value']['title'].toUpperCase().includes(keyword.toUpperCase()));
                if(filter.length > 0) {
                    return Promise.resolve(filter);
                }else{
                    return Promise.reject(`${keyword}`);
                }
            })
    }

    static checkAlbum(value){
        axios.get('https://wendiapp-favalbum-default-rtdb.firebaseio.com/albums.json')
        .then(response => {
            return response.data
        }).then(responeData => {
                const albums = [];
                for(const key in responeData){
                    const album = {
                        id : key,
                        ...responeData[key]
                    }
                    albums.push(album);
                }
                const filter = albums.filter(data => data['value']['title'].toUpperCase().includes(value['title'].toUpperCase()));
                if(filter.length > 0){
                alert(`${value['title']} is already on here`);
                }else{
                this.addAlbum(value)
                }
        })
    }

    static addAlbum(value){
        axios.post('https://wendiapp-favalbum-default-rtdb.firebaseio.com/albums.json', {value})
        .then(responese => {
            console.log(responese)
            alert(`${value['title']} success added on the favorites list`);
            location.reload(true);
        }).catch(error => {
            console.log(error)
        })
    }

    static deleteAlbum(id){
        console.log(id);
        axios.delete(`https://wendiapp-favalbum-default-rtdb.firebaseio.com/albums/${id}.json`).then(results => {
            console.log(results);
            location.reload(true);
        }).catch(error => {
            console.log(error);
        })
    }

    static editAlbum(id, data){
        console.log(id,data);
        axios.put(`https://wendiapp-favalbum-default-rtdb.firebaseio.com/albums/${id}/value.json`, data)
        .then(response => {
            location.reload(true);
            alert(`${data['title']} has been edited`);
        }).catch(error => {
            console.log(error);
        })
    }
}

export default DataSource;