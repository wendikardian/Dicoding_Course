import './album-list.css';
import DataSource from "../data/data-source.js";
import $ from 'jquery';
window.jQuery = window.$ = $;

class AlbumList extends HTMLElement{
    
    set albums(albums){
        this._albums = albums;
        this.render();
        $('.delete-album').click(event => {
            const id = event.target.id;
            confirm('Are you sure you want to delete this album');
            DataSource.deleteAlbum(id);
        })
        $('.edit-album-proccess').click(event => {
            const id = event.target.id;
            console.log(id);
            const editTitle = $(`#${id}title`).val();
            const editArtist = $(`#${id}artist`).val();
            const editImg = $(`#${id}img`).val();
            const editReleaseYear = $(`#${id}releaseYear`).val();
            const editTopSong1 = $(`#${id}topsong1`).val();
            const editTopSong2 = $(`#${id}topsong2`).val();
            const dataEdit = {
                title : editTitle,
                artist : editArtist,
                releaseYear : editReleaseYear,
                img : editImg,
                topSong : [
                    editTopSong1,
                    editTopSong2
                ]
            };
            DataSource.editAlbum(id ,dataEdit);
        })

    }

    render(){
        const albumCard = document.querySelector(".card-album");
        albumCard.innerHTML = '';
        this._albums.forEach(album => { 
            const div = document.createElement("div");
            div.classList.add("col-lg-4");
            div.innerHTML = `
                    <div class="col-lg-4 ">
                        <div class="card" style="width: 18rem;">
                            <img class="card-img-top" src="${album.value.img}" alt="Card image cap">
                            <div class="card-body">
                                <h5 class="card-title" style="font-weight: bold;">${album.value.title}</h5>
                                <p class="card-text">${album.value.artist}</p>
                                <p class="card-text">Release Date : ${album.value.releaseYear}</p>
                            </div>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item">1. ${album.value.topSong[0]}</li>
                                <li class="list-group-item">2. ${album.value.topSong[1]}</li>
                            </ul>
                            <div class="card-body">
                                <span class="card-link delete-album" id="${album.id}" style="color: red;">Delete</span>
                                <span class="card-link edit-album" data-target="#${album.value.title}" data-toggle="modal">Edit</span>
                            </div>
                        </div>
                    </div>


                    <div class="modal fade" id="${album.value.title}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Edit Album</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form>
                            <input type="text" id="${album.id}id" value="${album.id}" disabled style="display:none;">
                            <div class="form-group">
                                <label>Album title</label>
                                <input type="text" class="form-control" id="${album.id}title" placeholder="Album title" value="${album.value.title}"
                                readonly>
                            </div>
                            <div class="form-group">
                                <label >Artist</label>
                                <input type="text" id="${album.id}artist" class="form-control" placeholder="Artist" value="${album.value.artist}" required>
                            </div>
                            <div class="form-group">
                                <label >Img url</label>
                                <input type="text" id="${album.id}img" class="form-control" placeholder="Artist" value="${album.value.img}" required>
                            </div>
                            <div class="form-group">
                                <label>Release year</label>
                                <input type="number" class="form-control" id="${album.id}releaseYear" placeholder="Release year" value="${album.value.releaseYear}" required>
                            </div>
                            <div class="form-group">
                                <label>Top song</label>
                                <input type="text" class="form-control" id="${album.id}topsong1" placeholder="1" value="${album.value.topSong[0]}" required>
                                <input type="text" class="form-control" id="${album.id}topsong2" placeholder="2" value="${album.value.topSong[1]}" required>
                            </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary edit-album-proccess" id="${album.id}">Save changes</button>
                        </div>
                        </div>
                    </div>
                    </div>
            `;
        albumCard.appendChild(div);    
        })
    }

    renderError(message){
        const albumCard = document.querySelector(".card-album");
        albumCard.innerHTML = '';
        albumCard.innerHTML += `
            <div class="alert alert-dark" role="alert" style="margin-top: 50px; border-radius: 20px;">
                <b> ${message} </b> is not found
            </div>
        `;
    }


    
    
}

customElements.define("album-list", AlbumList);